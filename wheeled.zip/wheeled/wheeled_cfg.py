from __future__ import annotations
import math
import isaaclab.sim as sim_utils
from isaaclab.assets import ArticulationCfg
from isaaclab.actuators import ImplicitActuatorCfg
from isaaclab.utils import configclass

@configclass
class WheeledArmRobotCfg(ArticulationCfg):
    """
    复合轮腿机械臂机器人的标准配置资产。
    """
    # --- 1. 物理生成配置 (Spawn Configuration) ---
    # 定义 USD 文件路径、刚体属性、碰撞属性
    spawn = sim_utils.UsdFileCfg(
        usd_path="/home/moujank/project/wheeled/source/wheeled/wheeled/tasks/direct/wheeled/usd/usd/wheeled_arm.usd",
        activate_contact_sensors=True, # 开启碰撞传感器（如足底接触检测）
        
        # 刚体属性 (针对每一个 Link)
        rigid_props=sim_utils.RigidBodyPropertiesCfg(
            disable_gravity=False,
            retain_accelerations=False,
            linear_damping=0.0,       # 建议设为0，由控制算法处理阻尼
            angular_damping=0.0,
            max_linear_velocity=1000.0,
            max_angular_velocity=1000.0,
            max_depenetration_velocity=1.0, # 【关键】防止穿模爆炸
        ),
        
        # 关节树属性 (针对整个 Articulation 树)
        articulation_props=sim_utils.ArticulationRootPropertiesCfg(
            enabled_self_collisions=True, # 开启自碰撞（腿会不会踢到手？）
            solver_position_iteration_count=4,
            solver_velocity_iteration_count=1,
            fix_root_link=False,          # False = 移动机器人; True = 固定基座机械臂
        ),
    )

    # --- 2. 初始状态 (Initial State) ---
    init_state = ArticulationCfg.InitialStateCfg(
        pos=(0.0, 0.0, 0.5), # z=0.5 防止落地时卡进地面
        rot=(1.0, 0.0, 0.0, 0.0),
        joint_pos={
            # 使用正则匹配或全名
            "Hip.*": 0.0,
            "Knee.*": 0.0,
            "Hub.*": 0.0,     # 轮子初始位置
            "Arm.*": 0.0,    # 假设你的手臂关节叫 Arm_1, Arm_2...
            "Claw": 0.0,
        },
        joint_vel={".*": 0.0},
    )

    # --- 3. 执行器配置 (Actuators) ---
    # 这里的关键是：区分位置控制(PD)和速度控制
    actuators = {
        # 腿部：通常是位置控制 (高刚度 Stiffness, 中阻尼 Damping)
        "legs": ImplicitActuatorCfg(
            joint_names_expr=["Hip.*", "Knee.*"],
            effort_limit=150.0,
            velocity_limit=10.0,   # rad/s (约 570度/秒，比你之前的 10度 合理)
            stiffness=80.0,        # P gain
            damping=2.0,           # D gain
        ),
        
        # 轮子：通常是速度控制 (0 刚度, 高阻尼/驱动增益)
        # 驱动模式：Torque = stiffness * (pos_err) + damping * (vel_err)
        # 如果 stiffness=0，则变成了纯速度跟踪模式
        "wheels": ImplicitActuatorCfg(
            joint_names_expr=["HubL", "HubR"],
            effort_limit=25.0,
            velocity_limit=20.0,
            stiffness=0.0,         # 设为 0 以启用纯速度控制
            damping=10.0,          # 在速度控制中，这充当速度增益(Velocity Gain)
        ),
        
        # 机械臂：高精度位置控制
        "arm": ImplicitActuatorCfg(
            joint_names_expr=["Arm.*"],
            effort_limit=20.0,
            velocity_limit=2.0,
            stiffness=50.0,
            damping=1.0,
        ),

        "gripper": ImplicitActuatorCfg(
            joint_names_expr=["Claw"], # 匹配你夹爪的活动关节名
            stiffness=800.0,  # 抓取需要较硬的刚度，保证夹紧力
            damping=40.0,
            effort_limit=50.0, # 限制最大夹取力，防止把物体“挤飞”
        ),
    }

    # --- 4. 软限位 (Soft Limits) ---
    # 当关节接近极限时自动减速，防止撞击物理限位
    soft_joint_pos_limit_factor = 0.9