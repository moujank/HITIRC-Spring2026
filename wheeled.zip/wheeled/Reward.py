from isaaclab.utils import configclass
from isaaclab.managers import RewardTermCfg
from isaaclab.envs import mdp
from isaaclab.managers import SceneEntityCfg
from isaaclab.envs import ManagerBasedRLEnv
from isaaclab.assets import Articulation
#from isaaclab.sensors import ContectSensor
from isaaclab.utils.math import quat_apply_inverse, yaw_quat, quat_rotate_inverse

import torch

def joint_pos_l2(env: ManagerBasedRLEnv, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")) -> torch.Tensor:
    """惩罚关节位置与默认姿态之间的 L2 平方差。"""
    asset: Articulation = env.scene[asset_cfg.name]
    # 计算当前位置与默认位置的差值
    diff = asset.data.joint_pos[:, asset_cfg.joint_ids] - asset.data.default_joint_pos[:, asset_cfg.joint_ids]
    return torch.sum(torch.square(diff), dim=1)

def track_lin_vel_xy_yaw_frame_exp(
    env, std: float, command_name: str, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")
) -> torch.Tensor:
    """Reward tracking of linear velocity commands (xy axes) in the gravity aligned robot frame using exponential kernel."""
    # extract the used quantities (to enable type-hinting)
    asset = env.scene[asset_cfg.name]
    vel_yaw = quat_apply_inverse(yaw_quat(asset.data.root_quat_w), asset.data.root_lin_vel_w[:, :3])
    lin_vel_error = torch.sum(
        torch.square(env.command_manager.get_command(command_name)[:, :2] - vel_yaw[:, :2]), dim=1
    )
    return torch.exp(-lin_vel_error / std**2)

def feet_air_time(
    env: ManagerBasedRLEnv, command_name: str, sensor_cfg: SceneEntityCfg, threshold: float
) -> torch.Tensor:
    """Reward long steps taken by the feet using L2-kernel.

    This function rewards the agent for taking steps that are longer than a threshold. This helps ensure
    that the robot lifts its feet off the ground and takes steps. The reward is computed as the sum of
    the time for which the feet are in the air.

    If the commands are small (i.e. the agent is not supposed to take a step), then the reward is zero.
    """
    # extract the used quantities (to enable type-hinting)
    contact_sensor: ContactSensor = env.scene.sensors[sensor_cfg.name]
    # compute the reward
    first_contact = contact_sensor.compute_first_contact(env.step_dt)[:, sensor_cfg.body_ids]
    last_air_time = contact_sensor.data.last_air_time[:, sensor_cfg.body_ids]
    reward = torch.sum((last_air_time - threshold) * first_contact, dim=1)
    # no reward for zero command
    reward *= torch.norm(env.command_manager.get_command(command_name)[:, :2], dim=1) > 0.1
    return reward

def contact_forces_l2(env: ManagerBasedRLEnv, sensor_cfg: SceneEntityCfg) -> torch.Tensor:
    """惩罚足端的原始碰撞力大小（L2 范数）。"""
    contact_sensor: ContactSensor = env.scene.sensors[sensor_cfg.name]
    # 获取所有监测部件的合力大小
    net_forces = contact_sensor.data.net_forces_w[:, sensor_cfg.body_ids]
    return torch.sum(torch.square(net_forces), dim=(1, 2))

# 对应你源码中的 joint_torques_l2
def torques_l2(env: ManagerBasedRLEnv, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")) -> torch.Tensor:
    """惩罚关节施加的力矩。"""
    asset: Articulation = env.scene[asset_cfg.name]
    return torch.sum(torch.square(asset.data.applied_torque[:, asset_cfg.joint_ids]), dim=1)


def feet_slide(env, sensor_cfg: SceneEntityCfg, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")) -> torch.Tensor:
    """Penalize feet sliding.

    This function penalizes the agent for sliding its feet on the ground. The reward is computed as the
    norm of the linear velocity of the feet multiplied by a binary contact sensor. This ensures that the
    agent is penalized only when the feet are in contact with the ground.
    """
    # Penalize feet sliding
    contact_sensor: ContactSensor = env.scene.sensors[sensor_cfg.name]
    contacts = contact_sensor.data.net_forces_w_history[:, :, sensor_cfg.body_ids, :].norm(dim=-1).max(dim=1)[0] > 1.0
    asset = env.scene[asset_cfg.name]

    body_vel = asset.data.body_lin_vel_w[:, asset_cfg.body_ids, :2]
    reward = torch.sum(body_vel.norm(dim=-1) * contacts, dim=1)
    return reward

def stand_still_joint_deviation_l1(
    env, command_name: str, command_threshold: float = 0.06, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")
    ) -> torch.Tensor:
    """Penalize offsets from the default joint positions when the command is very small."""
    command = env.command_manager.get_command(command_name)
    # Penalize motion when command is nearly zero.
    return mdp.joint_deviation_l1(env, asset_cfg) * (torch.norm(command[:, :2], dim=1) < command_threshold)


def projected_gravity_l2(
        env: ManagerBasedRLEnv, asset_cfg: SceneEntityCfg, target_vec: tuple[float, float, float] = (0.0, 0.0, 1.0)
    ) -> torch.Tensor:
    """
    计算机器人投影重力与目标矢量之间的 L2 误差。
    用于维持双轮足机器人的直立平衡。
    """
    # 提取机器人资产
    asset = env.scene[asset_cfg.name]
    
    # 获取投影重力矢量 (Isaac Lab 已经在 asset.data 中维护了这个属性)
    # projected_gravity 是世界坐标系下 [0, 0, -1] 在机器人局部坐标系下的投影
    # 注意：如果机器人完全直立，projected_gravity 应该是 [0, 0, -1]
    # 如果你想让机器人背部朝天(直立)，我们需要对比它与 [-0, -0, -1] 的距离
    # 创建一个形状为 (num_envs, 3) 的张量，全部填充为 [0, 0, -1]
    gravity_vec = torch.tensor([0.0, 0.0, -1.0], device=env.device).repeat(env.num_envs, 1)
    current_projected_gravity = quat_rotate_inverse(asset.data.root_quat_w, gravity_vec)
    
    # 转换目标矢量为 Tensor
    target_tensor = torch.tensor(target_vec, device=env.device).repeat(env.num_envs, 1)
    
    # 计算 L2 距离的平方 (或开方)
    # 我们通常惩罚这个距离，所以返回的是负的误差
    return torch.norm(current_projected_gravity - target_tensor, dim=1)



def object_ee_distance(
        env: ManagerBasedRLEnv, object_cfg: SceneEntityCfg, ee_cfg: SceneEntityCfg, exponential: bool = False
    ) -> torch.Tensor:
    """计算末端执行器与物体之间的距离奖励。"""
    # 获取物体位置 (Root position)
    obj = env.scene[object_cfg.name]
    obj_pos = obj.data.root_pos_w # 世界坐标系位置
    
    # 获取末端执行器位置 (Body position)
    robot = env.scene[ee_cfg.name]
    ee_pos = robot.data.body_pos_w[:, ee_cfg.body_ids[0]] # 获取特定 link 的世界坐标
    
    # 计算欧氏距离
    distance = torch.norm(obj_pos - ee_pos, dim=-1)
    
    if exponential:
        return torch.exp(-2.0 * distance) # 越近奖励越高，呈指数级增长
    return distance # 返回原始距离，通常在 RewTerm 中权重设为负

def object_is_lifted(
        env: ManagerBasedRLEnv, object_cfg: SceneEntityCfg, table_height: float, threshold: float
    ) -> torch.Tensor:
    """判断物体是否被提离桌面。"""
    obj = env.scene[object_cfg.name]
    obj_height = obj.data.root_pos_w[:, 2] # 获取物体的 Z 轴高度
    
    # 如果高度超过 (桌面高度 + 阈值)，返回 1.0，否则返回 0.0
    lifted = (obj_height > (table_height + threshold)).float()
    return lifted

def contact_sensor_data(env: ManagerBasedRLEnv, sensor_cfg: SceneEntityCfg) -> torch.Tensor:
    """
    读取接触传感器的合力模长，作为奖励或观测值。
    用于引导机器人夹爪感知物体。
    """
    # 1. 从场景中获取传感器对象
    # 确保在 SceneCfg 中定义了名为 "ee_contact_sensor" 的传感器
    sensor = env.scene.sensors[sensor_cfg.name]
    
    # 2. 获取传感器受到的净力 (Net Forces)
    # sensor.data.net_forces_w 的维度是 (num_envs, num_bodies_in_sensor, 3)
    net_forces = sensor.data.net_forces_w
    
    # 3. 计算力的模长 (L2范数)
    # 我们对所有监测的 body（如果是双指夹爪，可能有两个 body）取力的模长
    force_magnitudes = torch.norm(net_forces, dim=-1) # (num_envs, num_bodies)
    
    # 4. 返回每个环境下的平均接触力（或者最大值）
    # 神经网络可以通过这个连续值感知“碰得重还是轻”
    return torch.mean(force_magnitudes, dim=-1)

def object_to_target_distance_filtered(
        env: ManagerBasedRLEnv, object_cfg: SceneEntityCfg, target_pos: tuple, table_height: float
    ) -> torch.Tensor:
    """只有当物体离开桌面后，才计算距离目标的惩罚。"""
    obj_pos = env.scene[object_cfg.name].data.root_pos_w
    is_lifted = (obj_pos[:, 2] > (table_height + 0.02)).float()
    
    target = torch.tensor(target_pos, device=env.device)
    distance = torch.norm(obj_pos - target, dim=-1)
    
    # 如果没提起，该项奖励为 0；提起了，返回负的距离值
    return is_lifted * (-distance)

@configclass
class RewardCfg:
    # --- 1. 线速度追踪：鼓励机器人跟随指令速度 ---
    # 使用指数函数是为了让误差越小时奖励增益越高（收敛更精准）
    track_lin_vel_xy_exp = RewardTermCfg(
        func=track_lin_vel_xy_yaw_frame_exp,
        weight=1.5,
        params={
            "std": 0.25,
            "command_name": "base_velocity",
            "asset_cfg": SceneEntityCfg(name="robot")
        }
    )
    
    # --- 2. 角速度追踪：鼓励机器人转向精准 ---
    track_ang_vel_z_exp = RewardTermCfg(
        func=mdp.track_ang_vel_z_exp, 
        weight=0.75, 
        params={
            "std": 0.5,
            "command_name": "base_velocity",
            "asset_cfg": SceneEntityCfg(name="robot")
        }
    )
    # --- 3. 基座高度：维持一个理想的离地高度 ---
    # 平地时高度较低稳，楼梯时需要拉高重心
    base_height_l2 = RewardTermCfg(
        func=mdp.base_height_l2, 
        weight=-2.0, 
        params={"target_height": 0.5, "asset_cfg": SceneEntityCfg("robot", body_names="base_link")}
    )

    # --- 4. 躯干水平约束：防止机器人大幅度前后摇晃或侧翻 ---
    # 投影重力向量 z 分量应接近 1.0
    projected_gravity = RewardTermCfg(
        func=projected_gravity_l2, 
        params={
            # --- 核心修正点：指定目标资产 ---
            "asset_cfg": SceneEntityCfg("robot"), 
        },
        weight=-0.05
    )

    # --- 5. 机械臂姿态：除非任务需要，否则手臂应收缩在稳定位置 ---
    # 惩罚手臂偏离初始设定的“折叠”位置
    arm_stow_position = RewardTermCfg(
        func=joint_pos_l2,
        weight=-0.1,
        params={"asset_cfg": SceneEntityCfg("robot", joint_names=["Arm.*"])}
    )
    # --- 6. 轮子旋转奖励：如果机器人在移动，给轮子转动正奖励 ---
    # 逻辑：平地时，轮子转动能高效产生位移，AI 会为了这个奖励狂滚轮子
    wheel_rotation = RewardTermCfg(
        func=mdp.joint_vel_l2, 
        weight=0.01, 
        params={"asset_cfg": SceneEntityCfg("robot", joint_names=["Hub.*"])}
    )

    # --- 7. 腾空时间奖励：鼓励“抬腿”动作 ---
    # 修正点：使用 SceneEntityCfg 指向我们在 Scene 中定义的传感器变量名
    feet_air_time = RewardTermCfg(
        func=feet_air_time, # 指向你提供的这个新函数
        weight=0.5,
        params={
            "command_name": "base_velocity", # 对应你的 CommandManager 键名
            "sensor_cfg": SceneEntityCfg(name="feet_contact"),
            "threshold": 0.5 # 只有腾空超过 0.5s 才奖励
        }
    )   

    # --- 8. 足端冲击惩罚：惩罚“剁脚” ---
    # 修正点：指向 feet_contact 传感器，并设定力矩阈值
    feet_contact_forces = RewardTermCfg(
        func=contact_forces_l2,
        weight=-0.001,
        params={
            "sensor_cfg": SceneEntityCfg(name="feet_contact"), 
        }
    )

    # --- 9. 动作平滑度：惩罚动作变化率 ---
    # 这个通常不需要指定 asset，mdp 函数默认会找 "robot"
    action_rate_l2 = RewardTermCfg(
        func=mdp.action_rate_l2, 
        weight=-0.01
    )

    # --- 10. 能耗惩罚：惩罚扭矩过大 ---
    # 它是实现“平地优先滚轮子”的关键，因为滚轮子省力
    torques_l2 = RewardTermCfg(
        func=torques_l2, 
        weight=-0.0001
    )

    # --- 11. 非法碰撞：底盘、膝盖或机械臂撞地直接重罚 ---
    # 修正点：指向专门监测 base 碰撞的传感器
    undesired_contacts = RewardTermCfg(
        func=mdp.undesired_contacts,
        weight=-1.0,
        params={
            "sensor_cfg": SceneEntityCfg(name="contact_forces"), 
            "threshold": 1.0
        }
    )

    # 在 RewardCfg 类中
    feet_slide = RewardTermCfg(
        func=feet_slide, # 或者你自定义的函数名
        params={
            "sensor_cfg": SceneEntityCfg("feet_contact", body_names=[".*wheel.*"]), # 明确指定 body
            "asset_cfg": SceneEntityCfg("robot", body_names=[".*wheel.*"]),        # 保持一致
        },
        weight=-0.25,
    )
    
    # 新增项
    stand_still = RewardTermCfg(
        func=stand_still_joint_deviation_l1,
        weight=-0.5,
        params={
            "command_name": "base_velocity",
            "asset_cfg": SceneEntityCfg(name="robot")
        }
    )
    survival = RewardTermCfg(
        func=mdp.is_alive, # 或者类似的存活检测函数
        weight=1.0,        # 权重给大一点
    )

@configclass
class GribRewardCfg:
    """融合了行走平衡与抓取任务的复合奖励配置"""

    # =========================================================================
    # 1. 基础平衡与生存（沿用并优化）
    # =========================================================================

    # 核心平衡：改用自定义的投影重力函数
    projected_gravity = RewardTermCfg(
        func=projected_gravity_l2,
        weight=-2.0,  # 提高权重，平衡是操作的前提
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "target_vec": (0.0, 0.0, -1.0),
        }
    )

    # 维持理想离地高度
    base_height_l2 = RewardTermCfg(
        func=mdp.base_height_l2, 
        weight=-1.0, 
        params={"target_height": 0.5, "asset_cfg": SceneEntityCfg("robot", body_names="base_link")}
    )

    # 非法碰撞惩罚（底盘撞地、撞桌子）
    undesired_contacts = RewardTermCfg(
        func=mdp.undesired_contacts,
        weight=-2.0,
        params={
            "sensor_cfg": SceneEntityCfg(name="contact_forces"), 
            "threshold": 1.0
        }
    )

    # =========================================================================
    # 2. 抓取任务阶段奖励（新增关键逻辑）
    # =========================================================================

    # 阶段 A: 接近物体
    # 驱动机器人和机械臂末端靠近 TargetCube
    reach_object = RewardTermCfg(
        func=object_ee_distance,
        weight=5.0,  # 高权重，主导第一阶段行为
        params={
            "object_cfg": SceneEntityCfg("TargetCube"),
            "ee_cfg": SceneEntityCfg("robot", body_names="claw_link"),
            "exponential": True  # 指数奖励，越近分越高
        }
    )

    # 阶段 B: 接触物体 (新增)
    # 鼓励夹爪与物体产生接触力，这是提起物体的前提
    object_contact_bonus = RewardTermCfg(
        func=contact_sensor_data, # 复用观测中的函数
        weight=0.5,
        params={"sensor_cfg": SceneEntityCfg("ee_contact_sensor")}
    )

    # 阶段 B: 提升物体（里程碑）
    # 只有物体离开桌面一定高度才触发
    object_lifted = RewardTermCfg(
        func=object_is_lifted,
        weight=20.0,  # 任务核心突破点，给巨额分
        params={
            "object_cfg": SceneEntityCfg("TargetCube"),
            "table_height": 0.42,
            "threshold": 0.05
        }
    )

    # 阶段 C: 搬运回原点
    # 引导机器人带着物体回到初始位置 (0, 0)
    bring_it_back = RewardTermCfg(
        func=object_to_target_distance_filtered,
        weight=-2.0,  # 惩罚距离，距离原点越远分越少
        params={
            "object_cfg": SceneEntityCfg("TargetCube"),
            "target_pos": (0.0, 0.0, 0.5) 
        }
    )

    # =========================================================================
    # 3. 动作质量与能效控制（沿用平滑项）
    # =========================================================================

    # 轮子旋转奖励：在移动过程中，鼓励滚轮子而不是滑行
    wheel_rotation = RewardTermCfg(
        func=mdp.joint_vel_l2, 
        weight=0.001, 
        params={"asset_cfg": SceneEntityCfg("robot", joint_names=["Hub.*"])}
    )

    # 惩罚动作抖动（保护电机）
    action_rate_l2 = RewardTermCfg(
        func=mdp.action_rate_l2, 
        weight=-0.01
    )

    # 在 RewardCfg 类中
    feet_slide = RewardTermCfg(
        func=feet_slide, # 或者你自定义的函数名
        params={
            "sensor_cfg": SceneEntityCfg("feet_contact", body_names=[".*wheel.*"]), # 明确指定 body
            "asset_cfg": SceneEntityCfg("robot", body_names=[".*wheel.*"]),        # 保持一致
        },
        weight=-0.1,
    )

    # 能耗惩罚：防止不必要的发力
    torques_l2 = RewardTermCfg(
        func=torques_l2, 
        weight=-0.0001
    )