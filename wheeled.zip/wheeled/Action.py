from isaaclab.utils import configclass
from isaaclab.envs.mdp import JointPositionActionCfg, JointVelocityActionCfg
from isaaclab.managers import SceneEntityCfg

@configclass
class ActionCfg:
    # 腿部和手臂：位置控制 (Relative Position Control)
    # 神经网络输出的是相对于当前位置的增量
    joint_pos = JointPositionActionCfg(
        asset_name="robot",
        joint_names=["Hip.*", "Knee.*", "Arm.*", "Claw"],
        use_default_offset=True,
        scale=0.5,
    )

    # 轮子：速度控制 (Velocity Control)
    # 神经网络直接控制轮子的转速
    wheel_vel = JointVelocityActionCfg(
        asset_name="robot",
        joint_names=["Hub.*"],
        scale=10.0,  # 这里的 scale 决定了最大转速
        use_default_offset=True,
    )
