from isaaclab.envs import ManagerBasedRLEnvCfg
from isaaclab.utils import configclass
from isaaclab.envs import ViewerCfg
from isaaclab.sim import SimulationCfg , PhysxCfg
from .scene_cfg import SceneCfg
from .manager import ObservationCfg, ActionCfg, EventCfg, RewardCfg, TerminationCfg, CommandsCfg
# 导入你之前定义的组件（此处为逻辑占位）
# from .my_scene_cfg import MyFullSceneCfg
# from .my_managers import MyObservationManagerCfg, MyActionManagerCfg, MyRewardManagerCfg, MyTermManagerCfg, MyEventCfg

@configclass
class WheeledTrainEnvCfg(ManagerBasedRLEnvCfg):
    """
    基于管理器的强化学习环境总配置。
    它像一个“中央调度台”，连接了所有独立的管理器配置。
    """
    # --- 全局策略设置 ---
    episode_length_s = 20.0      # 单个回合的最大时长（秒）
    decimation = 4               # 仿真步长缩减（每 2 步仿真计算 1 次 RL 动作）
    max_iterations = 2000
    is_finite_horizon = False    # 是否是有限步长任务
    
    viewer = ViewerCfg(
        eye=(5.0, 5.0, 5.0), 
        lookat=(0.0, 0.0, 0.0),
    )
    
    sim = SimulationCfg(
        dt = 0.002,                 # 物理步长 10ms (100Hz)
        render_interval = decimation, # 渲染间隔，通常与 RL 步长一致以节省性能
        device = "cuda:0",
        physx = PhysxCfg(
            # --- 求解器性能与精度 ---
            solver_type=1,                # 0: PGS (快但较软), 1: TGS (更准, 推荐用于机器人)
            max_position_iteration_count=8 ,     # 位置约束求解迭代次数。次数越多，物体越“硬”。
            max_velocity_iteration_count=1,     # 速度约束求解迭代次数。
            enable_ccd=True,             # 连续碰撞检测 (CCD)。防止高速物体穿模。
            enable_stabilization=False,     # 物理稳定化。开启后物体更稳定但可能更软。

            # --- 物理特性微调 ---
            bounce_threshold_velocity=0.5, # 弹跳阈值速度（低于此值不发生弹性跳动）
            friction_offset_threshold=0.04,# 摩擦力抵消阈值
            friction_correlation_distance=0.025,
            #contact_offset=0.02,          # 碰撞触发距离 (米)
            #rest_offset=0.0,              # 静止时的重叠距离
            #enable_ccd=True,              # 强烈建议开启 CCD
        ),
    )

    # --- 1. 场景配置 (The World) ---
    
    # 包含：地形(Terrain)、机器人(Robot)、灯光(Light)、传感器(Sensors)
    scene = SceneCfg(num_envs=1024, env_spacing=8.0)

    # --- 2. 观察管理器 (The Sight) ---
    # 定义：机器人能看到什么（关节位置、机身速度、激光雷达等）
    observations = ObservationCfg()

    # --- 3. 动作管理器 (The Muscles) ---
    # 定义：机器人如何行动（关节位置控制、力矩控制等）
    actions = ActionCfg()

    # --- 4. 事件管理器 (The Randomizer) ---
    # 定义：何时发生什么事（如：重置时随机化机器人的位置、随机化摩擦力等）
    events = EventCfg()

    # --- 5. 奖励与终止 (The Rules) ---
    # 定义：什么是好行为（奖励），什么时候该“重开”（终止）
    rewards = RewardCfg()
    
    terminations = TerminationCfg()

    commands = CommandsCfg()
