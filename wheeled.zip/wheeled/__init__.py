# Copyright (c) 2022-2025, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

import gymnasium as gym

from . import agents, wheeled_env, wheeled_env_cfg, wheeled_arm_env_cfg, wheeled_train_env_cfg
from .agents import ppo_cfg
##
# Register Gym environments.
##


gym.register(
    id="Template-Wheeled-Direct-v0",
    entry_point=f"{__name__}.wheeled_env:WheeledEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.wheeled_env_cfg:WheeledEnvCfg",
        "rsl_rl_cfg_entry_point": f"{agents.__name__}.rsl_rl_ppo_cfg:PPORunnerCfg",
    },
)

gym.register(
    id="Wheeled-v0",
    entry_point=f"{__name__}.wheeled_env:WheeledEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.wheeled_env_cfg:WheeledEnvCfg",
        "rsl_rl_cfg_entry_point": f"{agents.__name__}.rsl_rl_ppo_cfg:PPORunnerCfg",
    },
)

gym.register(
    id="Wheeled-terrians-v0",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": wheeled_arm_env_cfg.wheeledArmEnvCfg,
        "rsl_rl_cfg_entry_point": f"{agents.__name__}.rsl_rl_ppo_cfg:PPORunnerCfg",
    },
)

gym.register(
    id="Wheeled-terrians-v1",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": wheeled_train_env_cfg.WheeledTrainEnvCfg,
        "rsl_rl_cfg_entry_point": ppo_cfg.RSLRLPPORunnerCfg,
    },
)