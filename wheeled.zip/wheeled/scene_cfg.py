from isaaclab.scene import InteractiveSceneCfg
from isaaclab.terrains import TerrainImporterCfg
from isaaclab.sensors import ContactSensorCfg
from isaaclab.sim import SimulationCfg, PhysicsMaterialCfg, RigidBodyMaterialCfg
import isaaclab.sim as sim_utils
from isaaclab.assets import RigidObject, RigidObjectCfg
from isaaclab.utils import configclass
from isaaclab.assets import AssetBaseCfg
from isaaclab.sensors.ray_caster import RayCasterCfg
from isaaclab.sensors.ray_caster.patterns import GridPatternCfg
from isaaclab.utils.assets import ISAACLAB_NUCLEUS_DIR

from wheeled.tasks.direct.wheeled.terrians.terrains import ComRough_Terrain_Cfg
from wheeled.tasks.direct.wheeled.terrians.terrians_cfg import ROUGH_TERRAINS_CFG
from wheeled.tasks.direct.wheeled.asset.wheeled_arm_cfg import WheeledArmCfg
# 假设这是你之前定义的综合地图配置
# from your_config_file import MyComplexWorldCfg

@configclass
class SceneCfg(InteractiveSceneCfg):
    """包含地形和机器人的场景配置框架"""
    #---全局变量配置---
    num_envs = 1024              # 同时训练 4096 个机器人
    env_spacing = 8.0            # 每个环境占地 4x4 米
    lazy_sensor_update = True    # 优化开关

    # --- 1. 地形配置 (施工队) ---
    terrain = TerrainImporterCfg(
        prim_path="/World/ground",
        # 指定使用生成器模式
        terrain_type="generator",
        # 填入你刚才定义的综合大地图蓝图
        terrain_generator=ComRough_Terrain_Cfg(),
        max_init_terrain_level=None,          # 设置为 None，允许随机分布
        #num_envs = 1024,
        # 定义物理属性：决定机器人走在上面滑不滑
        physics_material=RigidBodyMaterialCfg(
            static_friction=1.0,     # 静态摩擦力
            dynamic_friction=1.0,    # 动态摩擦力
            restitution=0.1,         # 恢复系数（0代表完全不弹，适合土地/楼梯）
        ),
        visual_material=sim_utils.MdlFileCfg(
            mdl_path=f"{ISAACLAB_NUCLEUS_DIR}/Materials/TilesMarbleSpiderWhiteBrickBondHoned/TilesMarbleSpiderWhiteBrickBondHoned.mdl",
            project_uvw=True,
            texture_scale=(0.25, 0.25),
        ),
        # 可选：调试显示
        debug_vis=True,
    )

    # --- 2. 机器人配置 (这里以 Placeholder 为例) ---
    robot = WheeledArmCfg(
        prim_path="{ENV_REGEX_NS}/Robot"
    )

    '''
    #---相机传感器---
    camera = CameraCfg(
        prim_path="{ENV_REGEX_NS}/Robot/base_link/camera", # 注意：base_link 需根据你的机器人模型修改
        width=128,  # 强化学习常用低分辨率
        height=128,
        data_types=["rgb"],
        spawn=sim_utils.PinholeCameraCfg(focal_length=12.0),
    '''

    # --- 3. 光照配置 (让场景亮起来) ---
    light = AssetBaseCfg(
        prim_path="/World/defaultLight",
        spawn=sim_utils.DistantLightCfg(
            intensity=5000.0,      # 光照强度
            color=(0.75, 0.75, 0.75), # 光源颜色 (RGB)
            #exposure=0.0,          # 曝光度
        ),
        init_state=AssetBaseCfg.InitialStateCfg(
            pos=(0.0, 0.0, 15.0),  # 灯光位置（对于远光灯，位置不影响平行光方向，但影响可视化）
            rot=(0.924, 0.0, 0.383, 0.0) # 旋转四元数，决定阳光照射的角度（产生阴影的关键）
        ),
    )   
    '''
    # --- 4. 道具资产 (自定义变量名: cube) ---
    cube = RigidObjectCfg(
        prim_path="{ENV_REGEX_NS}/Cube",
        spawn=sim_utils.CuboidCfg(
            size=(0.5, 0.5, 0.5),
            physics_material=sim_utils.PhysicsMaterialCfg(),
            rigid_props=sim_utils.RigidBodyPropsCfg(),
            mass_props=sim_utils.MassPropsCfg(mass=1.0),
        ),
    )
    '''

    # 在你的 SceneCfg 中，必须有专门检测底盘碰撞的传感器
    contact_forces = ContactSensorCfg(
        prim_path="{ENV_REGEX_NS}/Robot/base_link", # 监听整个机器人
        # 核心：只过滤底盘/躯干（假设你的躯干叫 base_link），排除轮子！
        #filter_prim_paths_expr=["{ENV_REGEX_NS}/Robot/.*wheel.*"], 
        history_length=3,
        track_air_time=False,
    )

    # --- 特定部位传感器 (可选：用于检测轮子/足端是否接地) ---
    # 如果你的奖励函数里有 "feet_air_time" 或 "wheel_contact"，需要这个
    feet_contact = ContactSensorCfg(
        prim_path="{ENV_REGEX_NS}/Robot/.*wheel.*", # 正则匹配轮子
        history_length=1,
        track_air_time=True,
    )

    height_scanner = RayCasterCfg(
        prim_path="{ENV_REGEX_NS}/Robot/base_link",  # 扫描仪绑定的父级 link
        update_period=0.0,
        mesh_prim_paths=["/World/ground"],
        offset=RayCasterCfg.OffsetCfg(pos=(0.0, 0.0, 20.0)), # 从上方向下投射射线
        pattern_cfg=GridPatternCfg(resolution=0.1, size=[1.6, 1.0]), # 扫描范围 1.6m x 1.0m
        max_distance=100.0,
    )