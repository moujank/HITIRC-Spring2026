import torch
from isaaclab.utils import configclass
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.envs import mdp
from isaaclab.envs import ManagerBasedRLEnv
from isaaclab.utils.math import yaw_quat

def push_entity(env: ManagerBasedRLEnv, env_ids: torch.Tensor, asset_cfg: SceneEntityCfg, velocity_range: dict[str, tuple[float, float]]):
    """
    模拟外部推力：在训练过程中随机改变实体的根部速度。
    """
    # 提取资产（机器人）
    asset = env.scene[asset_cfg.name]
    # 获取当前的根部状态 (pos, quat, lin_vel, ang_vel)
    root_states = asset.data.default_root_state[env_ids].clone()
    
    # 随机生成 x 和 y 方向的速度增量
    num_resets = len(env_ids)
    vel_x = torch.distributions.Uniform(*velocity_range["x"]).sample((num_resets,)).to(env.device)
    vel_y = torch.distributions.Uniform(*velocity_range["y"]).sample((num_resets,)).to(env.device)
    
    # 叠加到当前的线性速度上 (root_states 的索引 7:10 是线性速度)
    asset.data.root_vel_w[env_ids, :2] += torch.stack([vel_x, vel_y], dim=-1)
    
    # 将修改后的速度写回物理仿真器
    asset.write_root_velocity_to_sim(asset.data.root_vel_w[env_ids], env_ids)

def reset_root_state_with_random_orientation(
    env: ManagerBasedRLEnv, 
    env_ids: torch.Tensor, 
    asset_cfg: SceneEntityCfg, 
    pose_range: dict[str, tuple[float, float]],
    velocity_range: tuple[float, float] = (0.0, 0.0)
):
    """
    重置物体位置：在指定的范围内随机化位置和偏航角(Yaw)。
    """
    asset = env.scene[asset_cfg.name]
    # 获取默认状态作为模板
    root_states = asset.data.default_root_state[env_ids].clone()
    
    num_resets = len(env_ids)
    
    # 1. 随机化位置 (Position)
    root_states[:, 0] = torch.distributions.Uniform(*pose_range["x"]).sample((num_resets,)).to(env.device)
    root_states[:, 1] = torch.distributions.Uniform(*pose_range["y"]).sample((num_resets,)).to(env.device)
    root_states[:, 2] = torch.distributions.Uniform(*pose_range["z"]).sample((num_resets,)).to(env.device)
    
    # 2. 随机化偏航角 (Yaw Rotation)
    yaw = torch.distributions.Uniform(*pose_range["yaw"]).sample((num_resets,)).to(env.device)
    root_states[:, 3:7] = yaw_quat(yaw) # 将偏航角转换为四元数
    
    # 3. 重置速度为 0 (或随机)
    root_states[:, 7:13] = 0.0 
    
    # 写入仿真器
    asset.write_root_state_to_sim(root_states, env_ids)

def reset_base(env, env_ids, asset_cfg=SceneEntityCfg("robot")):
    """将机器人的位置重置到地形环境的起始点"""
    asset = env.scene[asset_cfg.name]
    root_state = asset.data.default_root_state[env_ids].clone()
    
    # 1. 设置为地形块的正中心
    root_state[:, :3] = env.scene.terrain.env_origins[env_ids]
    
    # 2. 高度精确设置：中心点高度 + 0.1m
    root_state[:, 2] += 0.5  # 根据你的机器人高度调整这个值，确保它在地面上方
    
    # 3. 关键：将线速度和角速度清零，防止重置后乱飞
    root_state[:, 7:13] = 0.0 
    
    # 写入仿真
    asset.write_root_state_to_sim(root_state, env_ids)

@configclass
class EventCfg:
    # --- 1. 重置时随机化关节位置 ---
    # 让机器人每次重置时姿态都有微小差异，增加鲁棒性
    reset_joint_pos = EventTerm(
        func=mdp.reset_joints_by_offset,
        mode="reset",
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "position_range": (-0.2, 0.2),
            "velocity_range": (0.0, 0.0),
        },
    )

    # --- 2. 训练过程中随机推一把 (Push Robot) ---
    # 每隔一段时间随机给基座一个力，模拟被踢或撞击
    push_robot = EventTerm(
        func=push_entity,
        mode="interval",
        interval_range_s=(5.0, 10.0), # 每 5-10 秒推一次
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "velocity_range": {"x": (-0.5, 0.5), "y": (-0.5, 0.5)},
        },
    )
    
    reset_base = EventTerm(
        func=reset_base,
        mode="reset",
        params={
            "asset_cfg": SceneEntityCfg("robot"),
        },
    )
    '''
    reset_robot_main = EventTerm(
        func=mdp.reset_scene_to_default,
        params={
            #"pose_range": {"x": (-0.0, 0.0), "y": (-0.0, 0.0), "yaw": (-3.14, 3.14)},
            #"asset_cfg": SceneEntityCfg("robot", body_names=".*"),
        },
        mode="reset",
    )
    '''
@configclass
class GribEventCfg:
    """Configuration for events in the environment."""

    # --- 1. 机器人：重置时随机化关节位置 ---
    # 增加鲁棒性，防止机器人学会死记硬背某一个起步姿态
    reset_robot_joint_pos = EventTerm(
        func=mdp.reset_joints_by_offset,
        mode="reset",
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "position_range": (-0.1, 0.1),
            "velocity_range": (0.0, 0.0),
        },
    )

    # --- 2. 机器人：训练过程中随机推一把 (Push Robot) ---
    # 模拟外部干扰，增强双轮足的平衡抗扰能力
    push_robot = EventTerm(
        func=push_entity,
        mode="interval",
        interval_range_s=(5.0, 10.0), 
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "velocity_range": {"x": (-0.5, 0.5), "y": (-0.5, 0.5)},
        },
    )

    # --- 3. 物体：重置时随机化物体位置 (Randomize Object) ---
    # 核心：让物体出现在桌面上方的一个随机区域内
    # 假设桌面中心在 (0.6, 0.0)，高度在 0.42
    reset_object_position = EventTerm(
        func=reset_root_state_with_random_orientation,
        mode="reset",
        params={
            "asset_cfg": SceneEntityCfg("TargetCube"),
            "pose_range": {
                "x": (0.5, 0.7),      # 在桌面长度方向随机
                "y": (-0.15, 0.15),   # 在桌面宽度方向随机
                "z": (0.42, 0.42),    # 固定在桌面高度（或略高一点防止穿透）
                "roll": (0.0, 0.0),
                "pitch": (0.0, 0.0),
                "yaw": (-3.14, 3.14), # 物体水平方向旋转随机
            },
            "velocity_range": (0.0, 0.0), # 初始速度为0
        },
    )

    # --- 4. (可选) 机器人：重置时随机化底盘位置 ---
    # 如果你想训练机器人从不同距离走向桌子，可以取消注释
    # reset_robot_base = EventTerm(
    #     func=mdp.reset_root_state_with_random_orientation,
    #     mode="reset",
    #     params={
    #         "asset_cfg": SceneEntityCfg("robot"),
    #         "pose_range": {"x": (-0.2, 0.2), "y": (-0.2, 0.2), "yaw": (-0.2, 0.2)},
    #     },
    # )