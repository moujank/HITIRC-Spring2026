from isaaclab.utils import configclass
from isaaclab.managers import TerminationTermCfg as DoneTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.envs import mdp
import torch
from isaaclab.envs import ManagerBasedRLEnv

def root_pos_distance_from_target(
    env: ManagerBasedRLEnv, 
    asset_cfg: SceneEntityCfg, 
    target_pos: tuple, 
    threshold: float
) -> torch.Tensor:
    """
    判断物体的根部位置是否进入了目标点的阈值范围内。
    用于判定任务成功并触发重置。
    """
    # 获取资产（通常是 TargetCube）
    asset = env.scene[asset_cfg.name]
    # 当前世界坐标位置 (num_envs, 3)
    current_pos = asset.data.root_pos_w
    
    # 目标位置转换为 tensor
    target = torch.tensor(target_pos, device=env.device)
    
    # 计算欧式距离 (num_envs,)
    distance = torch.norm(current_pos - target, dim=-1)
    
    # 返回布尔 Tensor：距离小于阈值则为 True
    return distance < threshold

def joint_pos_out_of_manual_limit(
    env: ManagerBasedRLEnv, 
    asset_cfg: SceneEntityCfg, 
    bounds: tuple[float, float]
) -> torch.Tensor:
    """
    判断关节位置是否超出了手动设定的弧度范围。
    用于防止物理穿模或数值爆炸。
    """
    # 获取资产（机器人）
    asset = env.scene[asset_cfg.name]
    # 获取所有关节的当前位置 (num_envs, num_joints)
    joint_pos = asset.data.joint_pos
    
    # 判断是否有任何一个关节超过了上限或下限
    out_upper = torch.any(joint_pos > bounds[1], dim=-1)
    out_lower = torch.any(joint_pos < bounds[0], dim=-1)
    
    # 只要有一处超限即返回 True
    return torch.logical_or(out_upper, out_lower)

@configclass
class TerminationCfg:
    # --- 1. 超时终止 (Time Out) ---
    # 当达到任务设定的最大步数时重置。注意：这通常不扣分。
    time_out = DoneTerm(func=mdp.time_out, time_out=True)

    '''
    # --- 2. 跌倒终止 (Bad Collision) ---
    # 逻辑：当除轮子外的任何部位（如底盘 base_link）触碰地面且力量超过阈值时重置。
    # 需要你在 Scene 中定义名为 "base_contact" 的传感器。
    illegal_contact = DoneTerm(
        func=mdp.illegal_contact,
        params={
            "sensor_cfg": SceneEntityCfg(name="contact_forces"),
            "threshold": 200.0  # 10.0 Newton 的力即判定为碰撞
        }
    )
    '''
    # --- 3. 姿态异常终止 (Orientation) ---
    # 如果机器人翻车（例如躯干与重力方向夹角过大），直接重置。
    # 这样可以节省时间，不用等它彻底撞地。
    bad_orientation = DoneTerm(
        func=mdp.bad_orientation,
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "limit_angle": 60.0
        }
    )
    
    
    # --- 4. 关节位置超限 (Joint Limits) ---
    # 可选补充：如果关节强行撞击物理限位，重置环境以保护物理引擎稳定性。
    joint_out_of_limits = DoneTerm(
        func=mdp.joint_pos_out_of_manual_limit,
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "bounds": (-3.14, 3.14) # 根据你机器人的实际物理限位设置
        }
    )
    

@configclass
class GribTerminationCfg:
    """Configuration for termination terms in the environment."""

    # --- 1. 超时终止 (Time Out) ---
    # 达到最大仿真步数（例如 1000 步）后自动重置。
    time_out = DoneTerm(func=mdp.time_out)

    # --- 2. 跌倒/非法碰撞终止 (Illegal Contact) ---
    # 逻辑：除轮子外的部位触地即判定为跌倒。
    illegal_contact = DoneTerm(
        func=mdp.illegal_contact,
        params={
            "sensor_cfg": SceneEntityCfg("contact_forces"),
            "threshold": 1.0  # 1.0 Newton 的力
        }
    )

    # --- 3. 姿态异常终止 (Orientation) ---
    # 倾斜角超过约 57 度判定为翻车，提前重置。
    bad_orientation = DoneTerm(
        func=mdp.bad_orientation,
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "limit_angle": 1.0 
        }
    )

    # --- 4. 物体掉落终止 (Object Dropped - 失败) ---
    # 逻辑：如果物体高度低于某个阈值（说明掉下桌子），或者离开桌面太远，认为任务失败。
    object_dropped = DoneTerm(
        func=mdp.root_height_below_minimum,
        params={
            "asset_cfg": SceneEntityCfg("TargetCube"),
            "minimum_height": 0.1  # 桌面高 0.4，如果掉到 0.1 说明彻底失败
        }
    )

    # --- 5. 任务成功终止 (Success - 成功) ---
    # 逻辑：当物体被成功带回原点（例如距离原点 < 0.15m）时，提前重置。
    # 这能显著加快模型收敛，因为它不再进行无意义的后续动作。
    object_successfully_returned = DoneTerm(
        func=root_pos_distance_from_target,
        params={
            "asset_cfg": SceneEntityCfg("TargetCube"),
            "target_pos": (0.0, 0.0, 0.4), # 回到初始点高度
            "threshold": 0.15              # 容差范围
        }
    )

    # --- 6. 关节位置超限 (Joint Limits) ---
    # 保护物理引擎，防止关节穿模或数值爆炸。
    joint_out_of_limits = DoneTerm(
        func=joint_pos_out_of_manual_limit,
        params={
            "asset_cfg": SceneEntityCfg("robot"),
            "bounds": (-3.14, 3.14) 
        }
    )

