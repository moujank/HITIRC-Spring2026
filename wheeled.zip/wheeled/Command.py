from isaaclab.utils import configclass
from isaaclab.envs import mdp
# 注意：不需要导入 SceneEntityCfg 给 asset_name 使用

@configclass
class CommandsCfg:
    """定义任务指令：包含目标位姿和奖励函数需要的速度指令"""

    base_velocity = mdp.UniformVelocityCommandCfg(
        asset_name="robot",             # 修正：直接写字符串名称
        resampling_time_range=(10.0, 10.0), 
        #rel_standing_probability=0.2, 
        debug_vis=True,
        ranges=mdp.UniformVelocityCommandCfg.Ranges(
            lin_vel_x=(1.0, 1.0),
            lin_vel_y=(0.0, 0.0),
            ang_vel_z=(-0.14, 0.14),
        ),
    )
    
    base_pose = mdp.UniformPoseCommandCfg(
        asset_name="robot",             # 修正：直接写字符串名称，不要写 SceneEntityCfg("robot")
        body_name="base_link",
        resampling_time_range=(1.0e9, 1.0e9),  # 永不自动重采样
        debug_vis=True,
        ranges=mdp.UniformPoseCommandCfg.Ranges(
            pos_x=(0.5, 0.7),
            pos_y=(-0.2, 0.2),
            pos_z=(0.42, 0.42),
            roll=(0.0, 0.0),
            pitch=(0.0, 0.0),
            yaw=(-3.14, 3.14),
        ),
    )
    