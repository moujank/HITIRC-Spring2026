import torch
from isaaclab.utils import configclass
from isaaclab.envs import ManagerBasedRLEnv
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.envs import mdp
#from isaaclab.utils.math import subtract_frame
from isaaclab.utils.math import quat_rotate_inverse

def joint_torques_l2(env: ManagerBasedRLEnv, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")) -> torch.Tensor:
    """Penalize joint torques applied on the articulation using L2 squared kernel.

    NOTE: Only the joints configured in :attr:`asset_cfg.joint_ids` will have their joint torques contribute to the term.
    """
    # extract the used quantities (to enable type-hinting)
    asset: Articulation = env.scene[asset_cfg.name]
    return torch.sum(torch.square(asset.data.applied_torque[:, asset_cfg.joint_ids]), dim=1)

def joint_torques_raw(env: ManagerBasedRLEnv, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")) -> torch.Tensor:
    """获取关节的原始扭矩向量，用于 Critic 观测"""
    asset: Articulation = env.scene[asset_cfg.name]
    return asset.data.applied_torque[:, asset_cfg.joint_ids]

@configclass
class ObservationCfg:
    @configclass
    class PolicyCfg(ObsGroup):
        # --- 本体感受 (Proprioception) ---
        # --- 1. 平衡核心：本体感知 (Must-have for Inverted Pendulum) ---
        
        # 投影重力：将世界坐标系的 [0, 0, -1] 矢量转换到机器人局部坐标系
        # 这是双轮足平衡的“命根子”，它告诉机器人现在倒向了哪个方向。
        projected_gravity = ObsTerm(
            func=mdp.projected_gravity,
            params={"asset_cfg": SceneEntityCfg("robot")},
        )

        # 底盘角速度：模拟陀螺仪数据
        # 缩放 0.2 是为了将弧度/秒的值映射到神经网络更舒适的区间（通常是 [-1, 1]）
        base_ang_vel = ObsTerm(
            func=mdp.base_ang_vel,
            params={"asset_cfg": SceneEntityCfg("robot")},
            scale=0.2,
        )

        # 底盘线性速度（可选，但在移动任务中建议开启）
        base_lin_vel = ObsTerm(
            func=mdp.base_lin_vel,
            params={"asset_cfg": SceneEntityCfg("robot")},
            scale=2.0,
        )

        # 关节位置：通常需要缩放，将弧度缩放到较小的范围（如乘以 1.0）
        joint_pos = ObsTerm(
            func=mdp.joint_pos_rel, 
            params={"asset_cfg": SceneEntityCfg("robot")},
            scale=1.0 
        )
        
        # 关节速度：速度数值通常较大，建议缩小（如乘以 0.05）
        joint_vel = ObsTerm(
            func=mdp.joint_vel_rel, 
            params={"asset_cfg": SceneEntityCfg("robot")},
            scale=0.05
        )

        # --- 3. 任务与指令 ---

        # 速度指令：[v_x, v_y, omega_z]
        velocity_commands = ObsTerm(
            func=mdp.generated_commands,
            params={"command_name": "base_velocity"},
        )

        # 目标物体相对位置（如果你在做搬运任务，这个非常重要）
        # 假设你的 CommandCfg 中定义了 base_pose 追踪物块
        object_rel_pos = ObsTerm(
            func=mdp.generated_commands,
            params={"command_name": "base_pose"},
            scale=1.0,
        )

        # --- 外部感知 (Exteroception) ---
        
        # 高度扫描：神经网络对绝对高度不敏感，建议减去参考高度并缩放
        height_scan = ObsTerm(
            func=mdp.height_scan,
            params={"sensor_cfg": SceneEntityCfg(name="height_scanner")},
            scale=2.0,
            clip=(-1.0, 1.0) # 限制观察范围，防止异常值干扰
        )

        # --- 历史记录 (History) ---
        # 如果你想让机器人通过“感觉”来识别楼梯，可以开启历史记录
        # 这会将前 3 帧的动作拼在一起
        last_actions = ObsTerm(
            func=mdp.last_action,
            history_length=3,
            flatten_history_dim=True
        )
    @configclass
    class CriticCfg(ObsGroup):
        # 1. 基础速度 (3维)
        base_lin_vel = ObsTerm(
            func=mdp.base_lin_vel,
            params={"asset_cfg": SceneEntityCfg("robot")},
            scale=2.0
        )

        # 2. 角速度 (3维)
        base_ang_vel = ObsTerm(
            func=mdp.base_ang_vel,
            params={"asset_cfg": SceneEntityCfg("robot")},
            scale=0.25
        )

        # 3. 关节扭矩 (修正点：确保返回的是向量而非标量)
        joint_torques = ObsTerm(
            func=joint_torques_raw, 
            params={"asset_cfg": SceneEntityCfg("robot")},
            scale=0.01
        )

        # 4. 速度指令 (关键修正：mdp.generated_commands 默认可能维度不匹配)
        # 建议直接使用针对该命令的特定观察函数
        velocity_commands = ObsTerm(
            func=mdp.generated_commands,
            params={"command_name": "base_velocity"}
        )
        
        # 强制拼接选项 (如果还有微小不匹配，可以尝试显式关闭自动拼接)
        # 但通常建议修正维度。如果报错依旧，请在 CriticCfg 下添加：
        concatenate_terms = True

    policy: PolicyCfg = PolicyCfg()
    critic: CriticCfg = CriticCfg()

def object_position_in_robot_root_frame(
        env: ManagerBasedRLEnv, object_cfg: SceneEntityCfg, asset_cfg: SceneEntityCfg
    ) -> torch.Tensor:
    """计算物体相对于机器人基座(Root)的局部坐标。"""
    # 获取物体在世界系下的位置 (num_envs, 3)
    obj = env.scene[object_cfg.name]
    obj_pos_w = obj.data.root_pos_w
    
    # 获取机器人在世界系下的位置和朝向 (num_envs, 4)
    robot = env.scene[asset_cfg.name]
    robot_root_pos_w = robot.data.root_pos_w
    robot_root_quat_w = robot.data.root_quat_w # 四元数
    
    # 将物体的世界坐标转换到机器人的局部坐标系中
    # 使用公式：P_local = R_inv * (P_world - P_root)
    relative_pos_w = obj_pos_w - robot_root_pos_w
    
    obj_pos_b = quat_rotate_inverse(robot_root_quat_w, relative_pos_w)
    
    return obj_pos_b

def relative_body_pos_to_object(
        env: ManagerBasedRLEnv, asset_cfg: SceneEntityCfg, object_cfg: SceneEntityCfg
    ) -> torch.Tensor:
    """计算机器人特定 Link (如末端夹爪) 距离物体的位移矢量 (Object_pos - EE_pos)。"""
    # 获取物体世界位置
    obj = env.scene[object_cfg.name]
    obj_pos_w = obj.data.root_pos_w
    
    # 获取机器人末端执行器世界位置
    robot = env.scene[asset_cfg.name]
    # 注意：body_ids 会在管理器初始化时根据 body_names 自动填充
    ee_pos_w = robot.data.body_pos_w[:, asset_cfg.body_ids[0]]
    
    # 返回世界系下的相对位移 (num_envs, 3)
    return obj_pos_w - ee_pos_w

def contact_sensor_data(
        env: ManagerBasedRLEnv, sensor_cfg: SceneEntityCfg
    ) -> torch.Tensor:
    """获取接触传感器的力值或开关量。"""
    # 获取传感器资产
    sensor = env.scene.sensors[sensor_cfg.name]
    
    # 获取接触力的模长 (num_envs, num_bodies_in_sensor)
    # net_forces_w 形状是 (num_envs, num_bodies, 3)
    contact_forces = torch.norm(sensor.data.net_forces_w, dim=-1)
    
    # 我们通常返回一个布尔值或数值：1.0 表示接触，0.0 表示未接触
    # 这里我们返回力的大小，神经网络可以自己学习阈值
    return contact_forces

def generated_command_rel(
        env: ManagerBasedRLEnv, command_name: str, asset_cfg: SceneEntityCfg
    ) -> torch.Tensor:
    """获取 CommandManager 中的目标位姿并转到机器人局部系。"""
    target_pose_w = env.command_manager.get_command(command_name)
    target_pos_w = target_pose_w[:, :3]
    
    asset = env.scene[asset_cfg.name]
    robot_pos_w = asset.data.root_pos_w
    robot_quat_w = asset.data.root_quat_w
    
    relative_pos_w = target_pos_w - robot_pos_w
    return quat_rotate_inverse(robot_quat_w, relative_pos_w)

def task_phase_and_target_obs(
        env: ManagerBasedRLEnv, 
        object_cfg: SceneEntityCfg, 
        table_height: float, 
        asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")
    ) -> torch.Tensor:
    """
    逻辑切换观测：
    1. 判断物体是否被提起。
    2. 根据阶段返回物体位置或原点位置（在机器人局部坐标系下）。
    """
    # 获取物体世界坐标
    obj = env.scene[object_cfg.name]
    obj_pos_w = obj.data.root_pos_w
    
    # 获取机器人世界位姿
    robot = env.scene[asset_cfg.name]
    robot_pos_w = robot.data.root_pos_w
    robot_quat_w = robot.data.root_quat_w
    
    # 1. 阶段判断：物体高度 > 桌面高度 + 5cm 阈值
    is_lifted = (obj_pos_w[:, 2] > (table_height + 0.05)).float().unsqueeze(1)
    
    # 2. 目标点选择 (世界坐标系)
    # 起始点（返回点）设为原点上方 0.5m
    home_pos_w = torch.tensor([0.0, 0.0, 0.5], device=env.device).repeat(env.num_envs, 1)
    # 使用 torch.where 进行 Batch 级别的逻辑切换
    current_target_w = torch.where(is_lifted > 0.5, home_pos_w, obj_pos_w)
    
    # 3. 核心修正：转换到机器人局部坐标系 (Body Frame)
    # 公式：P_local = R_inv * (P_target_world - P_robot_world)
    relative_target_w = current_target_w - robot_pos_w
    relative_target_b = quat_rotate_inverse(robot_quat_w, relative_target_w)
    
    # 4. 拼接 [阶段标志, 相对目标x, 相对目标y, 相对目标z]
    return torch.cat([is_lifted, relative_target_b], dim=-1)

@configclass
class GribObservationCfg:
    """整合了本体感受、外部感知与指令追踪的观测配置"""

    @configclass
    class PolicyCfg(ObsGroup):
        # --- 本体感受 (Proprioception) ---
        
        joint_pos = ObsTerm(
            func=mdp.joint_pos_rel, 
            params={"asset_cfg": SceneEntityCfg("robot")},
            scale=1.0 
        )
        
        joint_vel = ObsTerm(
            func=mdp.joint_vel_rel, 
            params={"asset_cfg": SceneEntityCfg("robot")},
            scale=0.05
        )

        projected_gravity = ObsTerm(
            func=mdp.projected_gravity, 
            params={"asset_cfg": SceneEntityCfg("robot")}
        )

        base_ang_vel = ObsTerm(
            func=mdp.base_ang_vel,
            params={"asset_cfg": SceneEntityCfg("robot")},
            scale=0.25
        )

        # --- 外部感知 (Exteroception) ---
        
        # 物体相对于机器人的位置
        object_rel_pos = ObsTerm(
            func=object_position_in_robot_root_frame,
            params={"object_cfg": SceneEntityCfg("TargetCube"), "asset_cfg": SceneEntityCfg("robot")},
            scale=1.0
        )

        # 夹爪相对于物体的位置 (对准用)
        ee_to_object_pos = ObsTerm(
            func=relative_body_pos_to_object, 
            params={
                "asset_cfg": SceneEntityCfg("robot", body_names="claw_link"),
                "object_cfg": SceneEntityCfg("TargetCube")
            },
            scale=1.0
        )

        # 高度扫描 (避障与地形感知)
        height_scan = ObsTerm(
            func=mdp.height_scan,
            params={"sensor_cfg": SceneEntityCfg(name="height_scanner")},
            scale=2.0,
            clip=(-1.0, 1.0)
        )

        # --- 指令追踪 (Command Tracking) ---

        # 目标点相对于机器人的相对位置 (使用自定义函数替代 position_command_error)
        target_relative_pos = ObsTerm(
            func=generated_command_rel,
            params={
                "command_name": "base_pose",
                "asset_cfg": SceneEntityCfg("robot")
            },
            scale=1.0
        )

        # --- 辅助与历史 (Sensors & History) ---

        # 夹爪触觉
        object_contact = ObsTerm(
            func=contact_sensor_data,
            params={"sensor_cfg": SceneEntityCfg("ee_contact_sensor")}, 
            scale=0.01 
        )

        # 历史动作
        last_actions = ObsTerm(
            func=mdp.last_action,
            history_length=3,
            flatten_history_dim=True
        )

        task_status = ObsTerm(
            func=task_phase_and_target_obs,
            params={
                "object_cfg": SceneEntityCfg("TargetCube"),
                "table_height": 0.4, # 你的桌面高度
                "asset_cfg": SceneEntityCfg("robot")
            }
        )

    # 实例化 policy 组
    policy: PolicyCfg = PolicyCfg()