from isaaclab.terrains import (
    FlatPatchSamplingCfg,
    SubTerrainBaseCfg,
    TerrainGenerator,
    TerrainGeneratorCfg,
    TerrainImporter,
    TerrainImporterCfg,
    MeshBoxTerrainCfg,
    MeshFloatingRingTerrainCfg,
    MeshGapTerrainCfg,
    MeshInvertedPyramidStairsTerrainCfg,
    MeshPitTerrainCfg,
    MeshPlaneTerrainCfg,
    MeshPyramidStairsTerrainCfg,
    MeshRailsTerrainCfg,
    MeshRandomGridTerrainCfg,
    MeshRepeatedBoxesTerrainCfg,
    MeshRepeatedCylindersTerrainCfg,
    MeshRepeatedPyramidsTerrainCfg,
    MeshStarTerrainCfg,
    HfDiscreteObstaclesTerrainCfg,
    HfInvertedPyramidSlopedTerrainCfg,
    HfInvertedPyramidStairsTerrainCfg,
    HfPyramidSlopedTerrainCfg,
    HfPyramidStairsTerrainCfg,
    HfRandomUniformTerrainCfg,
    HfSteppingStonesTerrainCfg,
    HfTerrainBaseCfg,
    HfWaveTerrainCfg,
    )
from isaaclab.utils import configclass
import isaaclab.terrains.trimesh.mesh_terrains as mesh_terrains
import isaaclab.terrains.height_field.hf_terrains as hf_terrains

#平坦地块
@configclass
class MyFlatTerrainCfg(MeshPlaneTerrainCfg):
    # --- 核心生成配置 ---
    #function = hf_terrains.flat_terrain  # 内部自动指向 mesh_terrains.flat_terrain，通常不需要手动修改
    
    # --- 从 SubTerrainBaseCfg 继承的可配置关键字 ---
    size = (10.0, 10.0)  # 地形的宽度(x)和长度(y)，单位为米 (m)
    
    proportion = 1.0  # 该地形在整个地形生成器中所占的比例（权重）。
                      # 例如：如果有两个地形，A设为0.3，B设为0.7，则采样到A的概率为30%
    '''
    spawn_patches = FlatPatchSamplingCfg(
        num_patches=10,        # 采样 10 个点
        patch_radius=0.5,      # 半径 0.5 米
        max_height_diff=0.02   # 极度平整（高度差不超过 2 厘米）
    )
    
    # 2. 将其配置到字典中
    # 键名（如 "spawn_site"）由你决定，后续可以通过这个名字提取坐标
    flat_patch_sampling = {
        "spawn_site": spawn_patches
    }
   '''
    # --- 平整区域采样配置 (用于确定机器人出生点等) ---
    flat_patch_sampling = None  # 这是一个字典，键为名称，值为 FlatPatchSamplingCfg 对象。
                                # 设置后可以自动在地块上寻找适合放置机器人的平坦点。
    

#完全随机粗糙地块
#性能优化：如果你把 grid_width 设得非常小（比如 0.01），且 size 很大，生成的三角面片数量会爆炸。
#对于一般的四足机器人训练，0.1 到 0.2 是平衡仿真精度与性能的黄金区间。
#物理真实感：这种地形本质上是由无数垂直的面组成的。
#如果你想要那种平滑起伏的“小土丘”效果，通常会转而使用 HfTerrainCfg（高度场）
#但在 trimesh 中，MeshRandomGridTerrainCfg 是通过算法模拟崎岖感的最快方式。
@configclass
class MyRandomRoughTerrainCfg(MeshRandomGridTerrainCfg):

    function = mesh_terrains.random_grid_terrain
    proportion = 1.0    
    #border_width = 0.25
    # --- 核心几何参数 (必填) ---
    grid_width = 0.2               # 每个随机方块的边长 (米)。
                                    # 越小地面越“细碎”（类似碎石），越大则像“大石头堆”。
    grid_height_range = (0.02, 0.1) # 随机高度波动的范围 [min, max] (米)。
                                    # 决定了地面的粗糙程度或障碍物的最高高度。
    # --- 形状微调参数 (可选) ---
    platform_width = 2.0            # 地形中央预留的平坦正方形平台的边长 (米)。
                                    # 方便机器人在此处初始化。默认 1.0。
    holes = False                   # 是否随机镂空某些方块。
                                    # 若为 True，部分栅格将没有碰撞体，机器人会掉下去。默认 False。
    # --- 基础通用参数 (继承自 SubTerrainBaseCfg) ---
    size = (10.0, 10.0)               # 子地形的总长宽 (米)。
    proportion = 1.0                # 该地形在生成器中的采样概率权重。
    flat_patch_sampling = None      # 平整采样点字典。

#金字塔地块
#step_height_range 的最大值通常对应现实中楼梯的标准高度（约 0.15-0.18m）。如果你想挑战极限，可以设到 0.25m。
#step_width 越小，楼梯越陡。四足机器人通常需要 0.25m 以上才能稳住脚。
@configclass
class MyPyramidStairsCfg(MeshPyramidStairsTerrainCfg):
    # --- 核心几何参数 (必填) ---
    step_height_range = (0.05, 0.2)  # 阶梯高度范围 [min, max] (米)。系统会根据难度系数在该范围内取值。
    step_width = 0.3                # 每个阶梯的踏步宽度 (米)。
    
    # --- 形状微调参数 (可选) ---
    #border_width = 0.0              # 地形块四周边缘的平地宽度 (米)。默认为 0。
    #platform_width = 1.0            # 金字塔最顶端中心正方形平台的边长 (米)。默认 1.0。
    #platform_height = -1.0          # 平台的高度。若为负数，则自动设为金字塔的总高度（即最高点）。
    #holes = False                   # 是否在阶梯上留洞。若为 True，则只保留十字路径，其余部分为空，增加掉落风险。

    # --- 基础通用参数 (继承自 SubTerrainBaseCfgplatform_width) ---
    size = (10.0, 10.0)             # 该子地形的总长宽尺寸 (米)。
    proportion = 1.0                # 该地形在生成器中的采样概率权重。
    flat_patch_sampling = None      # 平整采样点字典（配置方式同上一节平地配置）。

#斜坡地块
#坡度与难度：slope_threshold 是斜坡最核心的参数。
#在强化学习中，我们通常会设置一个 slope_range，让机器人从 0.1（几乎平坦）练到 0.8（极陡）。
#摩擦力的重要性：在斜坡训练中，TerrainImporterCfg 里的摩擦力系数比形状本身更重要。如果摩擦力太小，机器人无论策略多好都会滑下来。
#方向性：注意这种生成的斜坡通常是向心的（类似金字塔坡）或单向的，取决于调用的具体底层函数。
@configclass
class MySlopeTerrainCfg(SubTerrainBaseCfg):
    # --- 核心生成函数 ---
    # 指定为斜坡生成函数
    #function = mesh_terrains.sloped_terrain

    # --- 斜坡专属参数 (通过配置传给函数) ---
    slope_threshold = 0.75          # 斜坡的坡度。数值越大越陡。
                                    # 通常 0.5 约为 26度，0.75 约为 37度。

    # --- 形状微调参数 ---
    platform_width = 1.0            # 斜坡顶部的平坦平台宽度 (米)。
    
    # --- 基础通用参数 (继承自 SubTerrainBaseCfg) ---
    size = (10.0, 10.0)             # 子地形的长宽尺寸 (米)。
    proportion = 1.0                # 该地形在生成器中的采样概率权重。
    flat_patch_sampling = None      # 平整采样点字典。

@configclass
class SlopeTerrainCfg(SubTerrainBaseCfg):
    # 明确指定使用 hf_terrains 里的函数
    function = hf_terrains.pyramid_sloped_terrain
    proportion = 1.0
    size = (10.0, 10.0)
    # 必须手动添加该函数需要的参数
    slope_range = (0.0, 0.4) 
    platform_width = 1.0

# 确保其他配置也没有 MISSING 值

@configclass
class MyPyramidStairsCfg(SubTerrainBaseCfg):
    function = hf_terrains.pyramid_stairs_terrain
    proportion = 1.0
    step_height_range = (0.05, 0.15) # 必须有 range
    step_width = 0.3
    platform_width = 1.0
    size = (10.0, 10.0)

#随机方块障碍物
#object_params_start vs object_params_end: 这是 Isaac Lab 的精髓。
#如果你把 num_objects 从 5 设到 50，把 height 从 0.02 设到 0.2，那么随着训练难度的提升，
#机器人会从“在稀疏的小木块间散步”进化到“在密集的乱石堆中攀爬”。
#max_yx_angle: 这个参数非常重要！
#如果设为 0，所有方块都是水平平放的；如果设为 30 度，方块会斜着插在地上。
# 对于四足机器人来说，斜面比平整的顶面更难落脚，能极大地提高策略的鲁棒性。
#object_type: 虽然我们在类名里选了 Boxes，但如果你查看基类，
#你可以通过修改 object_type 为 mesh_utils_terrains.make_cylinder 来瞬间把方块变成圆柱体。
@configclass
class MyRandomObstaclesCfg(MeshRepeatedBoxesTerrainCfg):
    # --- 1. 定义障碍物的属性 (ObjectCfg 内部类) ---
    @configclass
    class ObjectCfg(MeshRepeatedBoxesTerrainCfg.ObjectCfg):
        num_objects = 10         # 这一块地形中生成的障碍物数量
        size = (0.4, 0.4)        # 障碍物的长和宽 (x, y) 单位：米
        height = 0.1             # 障碍物的基础高度 (z) 单位：米
        max_yx_angle = 15.0      # 障碍物绕 Y 和 X 轴的最大随机倾斜角度
        degrees = True           # 上述角度单位是否为“度” (True) 还是“弧度” (False)

    # --- 2. 核心配置关键字 ---
    # 课程学习参数：定义简单（Start）和困难（End）情况下的物体参数
    # 系统会根据地形的“难度等级”在两者之间插值
    object_params_start = ObjectCfg(num_objects=5, height=0.05) 
    object_params_end = ObjectCfg(num_objects=20, height=0.15)

    # --- 3. 随机噪声与变化 ---
    abs_height_noise = (0.0, 0.05)   # 绝对高度噪声：给高度增加一个随机偏移量 [min, max]
    rel_height_noise = (0.8, 1.2)    # 相对高度噪声：给高度乘以一个随机系数 [min, max]
                                     # 最终高度 = height * rel_noise + abs_noise

    # --- 4. 布局微调 ---
    platform_width = 0.1            # 中心预留的圆形平坦区域直径 (米)
                                     # 机器人通常在此初始化，该范围内不会生成障碍物

    # --- 5. 基础通用参数 (继承自 SubTerrainBaseCfg) ---
    size = (10.0, 10.0)                # 子地形的总长宽尺寸 (米)
    proportion = 1.0                 # 该地形在生成器中的采样概率权重
    flat_patch_sampling = None       # 平整采样点字典

#随机圆柱障碍
@configclass
class MyRandomCylindersCfg(MeshRepeatedCylindersTerrainCfg):
    # --- 1. 定义圆柱体属性 ---
    @configclass
    class ObjectCfg(MeshRepeatedCylindersTerrainCfg.ObjectCfg):
        num_objects = 15         # 生成 15 个圆柱体
        radius = 0.2             # 圆柱体的半径 (米)
        height = 0.15            # 圆柱体的高度 (米)
        max_yx_angle = 10.0      # 最大随机倾斜角度 (度)
        degrees = True

    # --- 2. 核心配置关键字 ---
    # 课程学习：随着难度增加，圆柱体变多、变细、变高
    object_params_start = ObjectCfg(num_objects=5, radius=0.3, height=0.05)
    object_params_end = ObjectCfg(num_objects=25, radius=0.15, height=0.2)

    # --- 3. 随机噪声 ---
    abs_height_noise = (0.0, 0.02)   # 固定的高度波动
    rel_height_noise = (0.9, 1.1)    # 比例高度波动

    # --- 4. 布局与基础 ---
    platform_width = 1.2             # 中央出生点预留直径
    size = (10.0, 10.0)
    proportion = 1.0

#随机圆锥障碍
@configclass
class MyRandomConesCfg(MeshRepeatedPyramidsTerrainCfg):
    # --- 1. 定义圆锥属性 ---
    @configclass
    class ObjectCfg(MeshRepeatedPyramidsTerrainCfg.ObjectCfg):
        num_objects = 12
        radius = 0.25            # 圆锥底部的半径 (米)
        height = 0.2             # 圆锥顶点的高度 (米)
        max_yx_angle = 5.0       # 圆锥是否斜着插在地上
        degrees = True

    # --- 2. 核心配置关键字 ---
    # 难度梯度：从“矮胖”的圆锥变成“高瘦”的圆锥
    object_params_start = ObjectCfg(num_objects=5, radius=0.4, height=0.05)
    object_params_end = ObjectCfg(num_objects=15, radius=0.2, height=0.3)

    # --- 3. 基础通用参数 ---
    size = (10.0, 10.0)
    proportion = 0.1
    platform_width = 1.0        # 建议给圆锥地形留大一点的起始平台


#---以下是完整的地形设置---
#全平坦地形
@configclass
class FlatField_Terrains_Cfg(TerrainGeneratorCfg):
    """全平坦地形生成配置"""
    # 修正：改为字典并实例化
    sub_terrains = {
        "flat": MyFlatTerrainCfg()
    }
    size = (10.0, 10.0)     # 必须定义单个地块大小
    num_rows = 10           
    num_cols = 10           
    device = "cuda:0"       
    seed = 42               
    curriculum = False      
    difficulty_range = (0.0, 1.0) 
    use_cache = True        
    color_scheme = "random"

#完全粗糙地形
@configclass
class RoughField_Terrain_Cfg(TerrainGeneratorCfg):
    """由简单到困难的完全粗糙地形阵列"""
    # 修正：改为字典并实例化
    sub_terrains = {
        "rough": MyRandomRoughTerrainCfg()
    }
    size = (10.0, 10.0)
    num_rows = 10    
    num_cols = 5     
    curriculum = True               
    device = "cuda:0"
    seed = 1
    color_scheme = "random"

#斜坡地形
@configclass
class Sloped_Terrain_Cfg(TerrainGeneratorCfg):
    """用于课程学习的斜坡地形阵列"""
    # 修正：改为字典并实例化
    sub_terrains = {
        "slope": SlopeTerrainCfg()
    }
    size = (10.0, 10.0)
    num_rows = 10    
    num_cols = 5     
    curriculum = True               
    device = "cuda:0"
    seed = 42
    color_scheme = "per_height"

#楼梯地形
@configclass
class Stair_Terrain_Cfg(TerrainGeneratorCfg):
    """由浅入深的楼梯地形训练场"""
    # 修正：改为字典并实例化，且参数在内部传递
    sub_terrains = {
        "pyramid_stairs": MyPyramidStairsCfg(),
    }
    size = (10.0, 10.0)
    num_rows = 10    
    num_cols = 5     
    curriculum = True               
    device = "cuda:0"
    seed = 42
    color_scheme = "random"

@configclass
class Rough_Terrain_Cfg(TerrainGeneratorCfg):
    """自定义地形生成配置"""
    
    # 核心修正 1: sub_terrains 必须是字典，且配置项必须实例化 ()
    sub_terrains = {
        "flat": MyFlatTerrainCfg(proportion=0.1),
        "rough": MyRandomRoughTerrainCfg(proportion=0.2),
        "stairs": MyPyramidStairsCfg(proportion=0.2),
        "slope": SlopeTerrainCfg(proportion=0.2),
        "obstacles": MyRandomObstaclesCfg(proportion=0.1),
        "cylinders": MyRandomCylindersCfg(proportion=0.1),
        "cones": MyRandomConesCfg(proportion=0.1),
    }
    
    # 核心修正 2: 补充必要的生成参数
    size = (10.0, 10.0)         # 每个子地形方块的大小 (米)
    border_width = 5.0        # 地形边缘的宽度
    num_rows = 10             # 阵列行数
    num_cols = 10             # 阵列列数
    
    # 修正拼写错误: curriculum
    curriculum = True         
    
    # 其他参数
    device = "cuda:0"
    seed = 42
    difficulty_range = (0.0, 0.1) # 修正拼写: difficulty_range (注意双精度浮点数)
    color_scheme = "random"
    use_cache = True

@configclass
class Grib_Terrain_Cfg(TerrainGeneratorCfg):
    """抓取任务地形：平地与微粗糙结合"""
    # 修正：改为字典并实例化
    sub_terrains = {
        "flat": MyFlatTerrainCfg(proportion=0.5),
        "rough": MyRandomRoughTerrainCfg()
    }
    size = (10.0, 10.0)
    num_rows = 10
    num_cols = 10
    curriculum = True         # 修正拼写错误
    device = "cuda:0"
    seed = 42
    difficulty_range = (0.0, 0.1) # 修正拼写错误并保持格式一致
    color_scheme = "random"

'''
BoxCfg = MeshRepeatedBoxesTerrainCfg(
    proportion=0.1,
    platform_width=1.0,
    # 直接在这里定义 start 和 end 的参数对象
    object_params_start=MeshRepeatedBoxesTerrainCfg.ObjectCfg(
        num_objects=5, height=0.05, size=(0.4, 0.4)
    ),
    object_params_end=MeshRepeatedBoxesTerrainCfg.ObjectCfg(
        num_objects=20, height=0.15, size=(0.4, 0.4)
    ),
),
BoxCfg.platform_height = 0.2


PyramidCfg = MeshRepeatedPyramidsTerrainCfg(
    proportion=0.1,
    platform_width=1.0,
    # 同样直接实例化内部的 ObjectCfg
    object_params_start=MeshRepeatedPyramidsTerrainCfg.ObjectCfg(
        num_objects=5, radius=0.4, height=0.05
    ),
    object_params_end=MeshRepeatedPyramidsTerrainCfg.ObjectCfg(
        num_objects=15, radius=0.2, height=0.3
    ),
)
PyramidCfg.platform_height = 0.2
'''

@configclass
class ComRough_Terrain_Cfg(TerrainGeneratorCfg):
    curriculum = False
    size = (8.0, 8.0)
    border_width = 20.0
    num_rows = 10
    num_cols = 10
    use_cache = False
    color_scheme = "random"
    sub_terrains = {
        "flat": MeshPlaneTerrainCfg(
            proportion=0.2,
        ),
        "rough": HfRandomUniformTerrainCfg(
            proportion=0.2, 
            noise_range=(0.00, 0.02),
            noise_step=0.02,
            border_width=0.25
        ),
        "hf_pyramid_slope": HfPyramidSlopedTerrainCfg(
            proportion=0.1, 
            slope_range=(0.0, 0.4), 
            platform_width=2.0, 
            border_width=0.25
        ),
        "hf_pyramid_slope_inv": HfInvertedPyramidSlopedTerrainCfg(
            proportion=0.1,
            slope_range=(0.0, 0.4),
            platform_width=2.0,
            border_width=0.25
        ),
        "hf_pyramid_stairs": HfPyramidStairsTerrainCfg(
            proportion=0.1,
            step_height_range=(0.0, 0.1),
            step_width=0.3,
            platform_width=3.0,
            border_width=0.25
        ),
        "hf_pyramid_stairs_inv": HfInvertedPyramidStairsTerrainCfg(
            proportion=0.1,
            step_height_range=(0.0, 0.1),
            step_width=0.3,
            platform_width=3.0,
            border_width=0.25
        ),
        "wave_terrain": HfWaveTerrainCfg(
            proportion=0.2, 
            amplitude_range=(0.0, 0.2), 
            num_waves=4, 
            border_width=0.25
        ),
    }